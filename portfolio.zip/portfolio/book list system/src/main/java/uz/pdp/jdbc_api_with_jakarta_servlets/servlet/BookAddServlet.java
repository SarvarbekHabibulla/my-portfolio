package uz.pdp.jdbc_api_with_jakarta_servlets.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.postgresql.Driver;

import java.io.IOException;
import java.sql.*;

@WebServlet(name = "BookAddServlet", value = "/book/add")
public class BookAddServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/views/book/create.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        int pages = Integer.parseInt(request.getParameter("pages"));

        try {
            DriverManager.registerDriver(new Driver());
            Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jakarta?currentSchema=jdbc_example", "postgres", "postgres");
            PreparedStatement preparedStatement = connection.prepareStatement("insert into book(title, pages) values (?,?);");
            preparedStatement.setString(1, title);
            preparedStatement.setInt(2, pages);
            preparedStatement.execute();
            response.sendRedirect("/");
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
