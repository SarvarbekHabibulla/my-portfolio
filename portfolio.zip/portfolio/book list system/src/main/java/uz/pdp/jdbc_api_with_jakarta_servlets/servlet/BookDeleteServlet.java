package uz.pdp.jdbc_api_with_jakarta_servlets.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.postgresql.Driver;
import uz.pdp.jdbc_api_with_jakarta_servlets.model.Book;

import java.io.IOException;
import java.sql.*;

@WebServlet(name = "BookDeleteServlet", urlPatterns = "/book/delete/*")
public class BookDeleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        int id = Integer.parseInt(pathInfo.substring(1));

        try {
            DriverManager.registerDriver(new Driver());
            Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jakarta?currentSchema=jdbc_example", "postgres", "postgres");
            PreparedStatement preparedStatement = connection.prepareStatement("select * from book b where b.id = ?;");
            preparedStatement.setInt(1,id);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                Book book = (Book.builder()
                        .id(resultSet.getInt("id"))
                        .title(resultSet.getString("title"))
                        .pages(resultSet.getInt("pages"))
                        .build());
                request.setAttribute("book",book);
                RequestDispatcher dispatcher = request.getRequestDispatcher("/views/book/delete.jsp");
                dispatcher.forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        int id = Integer.parseInt(pathInfo.substring(1));

        try {
            DriverManager.registerDriver(new Driver());
            Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jakarta?currentSchema=jdbc_example", "postgres", "postgres");
            PreparedStatement preparedStatement = connection.prepareStatement("delete from book b where b.id = ?;");
            preparedStatement.setInt(1,id);
            preparedStatement.execute();
            response.sendRedirect("/");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
