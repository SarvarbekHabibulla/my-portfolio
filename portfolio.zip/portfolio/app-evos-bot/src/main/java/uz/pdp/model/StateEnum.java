package uz.pdp.model;

public enum StateEnum {
    MAIN_PAGE,
    ADDRESS,
    OLD_ADDRESSES,
    ROOT_CATEGORY,
    CHILD_CATEGORY,
    LOCATION_ACCEPTED,
    COMMENT,
    SETTING,
    LANGUAGES
}
